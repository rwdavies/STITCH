test_that("phase estimation can work with no errors", {
    test <- cbind(
        c(0, 1, 0, 0),
        c(1, 0, 1, 1)
    )
    truth <- test
    pse <- calculate_pse(test, truth)
    expect_equal(
        pse,
        0
    )
})

test_that("phase estimation can work with a het wrongly assigned", {
    test <- cbind(
        c(0, 1, 0, 0),
        c(1, 0, 1, 1)
    )
    truth <- cbind(
        c(0, 0, 0, 0),
        c(1, 1, 1, 1)
    )
    pse <- calculate_pse(test, truth)
    expect_equal(
        pse,
        2 / 3
    )
})

test_that("phase estimation can work with a het wrongly assigned", {
    test <- cbind(
        c(0, 0, 0, 0, 0),
        c(1, 1, 1, 1, 1)
    )
    truth <- cbind(
        c(0, 0, 1, 1, 1),
        c(1, 1, 0, 0, 0)
    )
    pse <- calculate_pse(test, truth)
    expect_equal(
        pse,
        1 / 4
    )
})


test_that("phase estimation skips truth hom sites", {
    test <- cbind(
        c(0, 0, 0, 0, 0),
        c(1, 1, 0, 1, 1)
    )
    truth <- cbind(
        c(0, 0, 0, 1, 1),
        c(1, 1, 1, 1, 1)
    )
    pse <- calculate_pse(test, truth, seed = 1) ## is random
    expect_equal(
        pse,
        1 / 2
    )
})


test_that("phase estimation deals with non-integer test data", {
    test <- cbind(
        c(0.1, 0.2, 0.1, 0.1, 0.1),
        c(0.9, 0.8, 0.7, 0.6, 0.9)
    )
    truth <- cbind(
        c(0, 0, 0, 1, 1),
        c(1, 1, 1, 1, 1)
    )
    pse <- calculate_pse(test, truth, seed = 1) ## is random
    expect_equal(
        pse,
        0 / 3
    )
})
