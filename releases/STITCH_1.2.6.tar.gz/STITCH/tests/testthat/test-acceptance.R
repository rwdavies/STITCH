phasemaster <- matrix(c(c(0, 0, 0), c(1, 1, 1)), ncol = 2)
data_package <- make_acceptance_test_data_package(
    n_samples = 10,
    n_snps = 3,
    n_reads = 4,
    seed = 1,
    chr = 10,
    K = 2,
    phasemaster = phasemaster
)

test_that("STITCH works under default parameters", {

    sink("/dev/null")
    STITCH(
        tempdir = tempdir(),
        chr = data_package$chr,
        bamlist = data_package$bamlist,
        posfile = data_package$posfile,
        outputdir = data_package$outputdir,
        K = 2,
        nGen = 100,
        nCores = 1
    )
    sink()

    vcf <- read.table(
        file.path(data_package$outputdir, paste0("stitch.", data_package$chr, ".vcf.gz")),
        header = FALSE,
        stringsAsFactors = FALSE
    )

    check_vcf_against_phase(
        vcf = vcf,
        phase = data_package$phase,
        tol = 0.2
    )

})

