// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-

#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]

#include <cmath>
#include <vector>
#include <iostream>
#include <algorithm>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
using namespace Rcpp;



// note - had an old version of reformatReads
// circa early november 2015, at least
// not sure why I was using it? what it was for


// EXAMPLE of how to export if desired
////' Reformat the reads for a single individual
////' 
////' @param x Describe parameters here.
////' @export
//// [[Rcpp::export]]



//' @export
// [[Rcpp::export]]
Rcpp::NumericVector increment2N(int yT, int xT, Rcpp::NumericVector y, Rcpp::NumericVector z) {
  Rcpp::NumericVector x(xT+1);
  int t;
  for(t=0; t<=yT-1; t++)
    x[z[t]]=x[z[t]]+y[t];
  return(x);
}


//' @export
// [[Rcpp::export]]
List cpp_cigar_split(std::vector <std::string> strings) {
  int num_strings = strings.size();
  List out(num_strings);
  
  for( int i=0; i < num_strings; i++ ) {

    if (isdigit(0)) {
      int a = 1;
    }

    // loop over, if a digit, add
    int p = 0; // now 0-based
    std::vector<int> t5;
    std::vector<char> t6;
    for(int j=0; j < strings[i].length(); j++) {
      if (! isdigit( strings[i].substr(j, 1)[0] )) {
	// std::cout << "i=" << i << ", j=" << j << ", p=" << p << " \\n";
          t5.push_back( std::stoi(strings[i].substr(p, j-p)) );
	t6.push_back( strings[i].substr(j, 1)[0]);
	p = j + 1;
      }
    }
      
    out[i] = List::create(t5, t6);
    //sampleReads.push_back(Rcpp::List::create(pR.size()-1,0,qR,pR,iRead));
      
  }
  
  return out;
}







//' @export
// [[Rcpp::export]]
Rcpp::List reformatReads(arma::ivec mapq, arma::ivec readStart, arma::ivec readEnd, const int numberOfReads, const int T, arma::ivec L, Rcpp::CharacterVector seqRead, Rcpp::CharacterVector qualRead,  Rcpp::CharacterVector ref,  Rcpp::CharacterVector alt, Rcpp::List splitCigarRead, arma::ivec lengthOfSplitCigarRead, const int bqFilter, const int verbose) {
//
// new variables
//
  int x1, x2, y, i, iPair, iM, iRead, t;
  int nSNPInRead = -1;
  int nReadSpanningSNPs = 0;
  char s;
  double d, phiRef, phiAlt, phi;
  double phiTemp = 1;
  Rcpp::List sampleReads;
  arma::ivec seqLocal(1000);
  arma::ivec qualLocal(1000);
  arma::ivec posLocal(1000); // there shouldnt be this many SNPs
  int refPosition, refOffset, strandOffset;
  int iNumOfMs, loopEnd, cigarLength;
  Rcpp::CharacterVector cigarType(1);
  Rcpp::CharacterVector cigar2(1);
  int iU, nU, iAll, curPos, whileVar, localbq;
  //
  // begin
  //
  // want - tMin - first SNP after last SNP before read
  // also - tMax - first SNP before last SNP after read
  // if the distance is >=0 between them, it is in that read
  //
  int tMin=0; 
  int tMax=-1; // left and right boundaries of what SNPs to look at
  for(iRead=0; iRead<=numberOfReads-1; iRead++)
  {
    // get current read position
    whileVar=0;
    // for t-Min
    while(whileVar==0)
    {
      // dont continue if too far
      if(tMin<(T-1))
      {
        // continue 
        if(L(tMin)<readStart[iRead])
        {
          tMin++;
        } else {
          whileVar=1; // break loop - done!
        }
      } else {
        whileVar=1; // break loop
      }
    }
    // now - go right
    whileVar=0;
    while(whileVar==0)
    {
      // dont continue if too far
      if(tMax < (T - 1))
      {
	if(L(tMax + 1) <= readEnd[iRead])
        {
	  // number is only to deal with weird cigars	  
          tMax++;
        } else {
          whileVar=1; // break loop - done!
        }
      } else {
	tMax = T - 1; // done, cannot be larger
        whileVar=1; // break loop
      }
    }
    //
    //
    // now, for this read, calculate whether there are SNPs - only bother if tMin>=tMax
    //
    //
    if(verbose == 1) {
            std::cout << "iRead=" << iRead;
            std::cout << ",tMin=" << tMin;
            std::cout << ",tMax=" << tMax;
            std::cout << "\\n";
    }
    nSNPInRead=-1;
    if(tMin<=tMax)
    {
      refPosition=readStart(iRead);
      Rcpp::List cigarReadInfo = as<Rcpp::List>(splitCigarRead(iRead));
      iNumOfMs = lengthOfSplitCigarRead(iRead);
      // set some things
      refOffset=0; // offset against the reference sequence
      strandOffset=0; // offset in the strand
      // get cigar info from the read
      arma::ivec cigarLengthVec = as<arma::ivec>(cigarReadInfo(0));
      Rcpp::CharacterVector cigarTypeVec = as<Rcpp::CharacterVector>(cigarReadInfo(1));
      //
      // now, loop over each part of the read (M, D=del, I=ins)
      //
      for(iM=0;iM<=iNumOfMs;iM++)
      {
        cigarLength=cigarLengthVec(iM);
        cigarType(0)=cigarTypeVec(iM);
        // if its an M - scan
        if(cigarType(0)=="M")
        {
          x1 = refPosition + refOffset; // left part of M
          x2 = refPosition + refOffset + cigarLength-1; // right part of M
          for(t=tMin; t<=tMax; t++) // determine whether that snps is spanned by the read
          {
            y = L[t];
            if(x1 <= y && y <= x2) // if this is true - have a SNP!
            {
              s = seqRead[iRead][y-refPosition-refOffset+strandOffset];
              // check if ref or ALT - only keep if true
              // also only use if BQ at least bqFilter (17) (as in 17 or greater)
              localbq=int(qualRead[iRead][y-refPosition-refOffset+strandOffset])-33;
              // also bound BQ above by MQ
              if(localbq>mapq(iRead)) // if greater, than reduce
                localbq=mapq(iRead);
//    if(verbose == 1) {
//            std::cout << "checking - iRead=" << iRead;
//            std::cout << ",s=" << s;
//            std::cout << ",ref[t][0]=" << ref[t][0];
//            std::cout << ",alt[t][0]=" << alt[t][0];
//            std::cout << ",t=" << t;
//           std::cout << ",y=" << y;
//            std::cout << ",x1=" << x1;
//            std::cout << ",x2=" << x2;
//            std::cout << "\\n";
//    }
              if((s==ref[t][0] || s==alt[t][0]) && (localbq>=bqFilter))
              {
                // is this the reference or alternate?
                nSNPInRead = nSNPInRead+1;
                if(s==ref[t][0])
                {
                  seqLocal[nSNPInRead] = 0;
                  qualLocal[nSNPInRead] = - localbq;
                }
                if(s==alt[t][0])
                {
                  seqLocal[nSNPInRead] = 1;
                  qualLocal[nSNPInRead] = localbq;
                }
                posLocal[nSNPInRead] = t;
              } // end of check if ref or alt
            } // end of whether this SNP intersects read
          } // end of loop on SNP
          // now, bump up ref and pos offset by x1
          refOffset=refOffset + cigarLength;
          strandOffset=strandOffset + cigarLength;
        } // end of if statement on whether cigar type is M
        // if it is an insertion - bump the strand offset
        if(cigarType(0)=="I")
          strandOffset=strandOffset+cigarLength;
        // if it is a deletion - bump the reference position
        if(cigarType(0)=="D")
          refOffset=refOffset+cigarLength;
      } // close loop on M
    } // end of check on whether there can be results to run
    //
    // save result if it is worth saving!
    //
    if(nSNPInRead > -1) // save result!
    {
    //if(verbose == 1) {
    //        std::cout << "saving - iRead=" << iRead;
     //       std::cout << ",nSNPInRead=" << nSNPInRead;
     //       std::cout << ",tMin=" << tMin;
     //       std::cout << ",tMax=" << tMax;
     //       std::cout << "\\n";
   // }
      arma::ivec pR = posLocal.subvec(0,nSNPInRead); // position (R means Read)
      arma::ivec sR = seqLocal.subvec(0,nSNPInRead); // sequence
      arma::ivec qR = qualLocal.subvec(0,nSNPInRead); // quality
      //
      // save results but dont label list elements to save space
      //
      // save a smaller version unless need to debug
      sampleReads.push_back(Rcpp::List::create(pR.size()-1,0,qR,pR,iRead));
      nReadSpanningSNPs = nReadSpanningSNPs +1;
    }  // end of save result
  } // end of loop on read
  //
  // done
  //
  return(wrap(sampleReads));
}




//      d=0;
//      for(i=0; i<=nSNPInRead; i++)
//        d = d + L(pR(i));
//      d = d/(1+nSNPInRead);

//      for(iU=0; iU<=nU; iU++) // for each unique entry
//      {
//        // reset phis
//        phiAlt=1;
//        phiRef=1;
//        // go through all elements looking for that SNP
//        for(iAll=0; iAll<=nSNPInRead; iAll++)
//        {
//          if(pR(iAll)==pRU(iU)) // there is a match - consider
//          {
//            // turn into phi
//            //   calculate probability from phred scale
//            phiTemp= pow(10,-(double(qR(iAll))/10));
//            // scale to appropriate base
//            phi = (  (phiTemp) * (1-sR(iAll))/(double)3  +  (1-phiTemp) * sR(iAll)  ) / (1-(2/(double)3)*phiTemp);
//           // phiTemp= 1 - pow(10,-(double(qR(iAll))/10));
//            // phi = (1-phiTemp) * ( 1-sR(iAll)) + phiTemp * sR(iAll);
// just in case I ever need to revisit this thing
//            double twoThird = 2/(double)3;
//           if(qR(iAll)<=0)
//              phi=0.5; // BQ = 0 so no probability so make it 0.5
//            phiAlt=phiAlt * phi;
//            phiRef=phiRef * (1-phi);
            // } // end if statement on whether there is a match
          //} // end of for loop going through all SNPs in the read
        // now calculate probability - calculate numerator and denominator
        // where for a= product_{i=0} P(alt,i)
        // where for b= product_{i=0} (1-P(alt,i))
        // phi = P(alt) = a/(a+b)
        //phiU(iU)=phiAlt/(phiAlt+phiRef); // done!
        //      } // end of for loop for each unique element

//    if(verbose == 1) {
//            std::cout << "saving - iRead=" << iRead;
//            std::cout << ",iAll=" << iAll;
//            std::cout << ",phiTemp=" << phiTemp;
//            std::cout << ",phi=" << phi;
//            std::cout << ",1-(twoThird)*phiTemp=" << 1-(twoThird)*phiTemp;
//            std::cout << ",1-(2/(double)3)*phiTemp=" << 1-(2/(double)3)*phiTemp;
//            std::cout << ",phiTemp*(1-2/3)=" << phiTemp * 1-(2/3);
//            std::cout << ",(phiTemp) * (1-sR(iAll))/(double)3=" << (phiTemp) * (1-sR(iAll))/(double)3;
//            std::cout << ",phi=" << phi << "\\n";
//    }











//' @export
// [[Rcpp::export]]
Rcpp::List forwardBackwardDiploid(Rcpp::List sampleReads,const int nReads, arma::vec pi, arma::vec sigma, arma::mat transMatRate, arma::mat alphaMat, arma::mat eHaps,   const double maxDifferenceBetweenReads, const int whatToReturn, const int Jmax, const int suppressOutput, const int model) {
  double  prev=clock();
  //
  // constants
  //
  const int T = eHaps.n_rows;
  const int K = eHaps.n_cols; // traditional K for haplotypes
  const int KK = K*K; // KK is number of states / traditional K for HMMs
  const double KKd = KK;
  const double Kd = K;
  //
  // new variables
  //
  // variables working on nReads
  arma::mat alphaHat = arma::zeros(T,KK);
  arma::mat betaHat = arma::zeros(T,KK);
  arma::vec c = arma::zeros(T);
  arma::vec c2 = arma::zeros(T);
  arma::mat gamma = arma::zeros(T,KK);
  arma::mat eMat = arma::zeros(T,KK);
  // define eMatHap to work on the number of reads
  arma::mat eMatHap = arma::zeros(nReads,K);
  // variables for faster forward backward calculation
  double alphaConst, betaConst;
  arma::vec alphaTemp1 = arma::zeros(K);
  arma::vec alphaTemp2 = arma::zeros(K);
  arma::vec betaTemp1 = arma::zeros(K);
  arma::vec betaTemp2 = arma::zeros(K);
  // variables working on full space
  arma::mat jUpdate = arma::zeros(T-1,K);
  arma::cube gammaUpdate = arma::zeros(T,K,2);
  arma::mat hapProbs = arma::zeros(T,K);
  arma::mat genProbs = arma::zeros(T,3);
  arma::vec dosage = arma::zeros(T);
  // variables for transition matrix and initialization
  // int variables and such
  int pLeft, pRight, tLeft, tRight;
  arma::vec g1 = arma::zeros(KK);
  arma::vec g2 = arma::zeros(KK);
  int i, j, k, kk, kl, t, k1, k2, k3, k4,iRead, cr;
  int i1, i2, j1, j2;
  int J, readSNP;
  double x, a, b, d, e, d1, d2, d3, cur, phi;
  double s1,s2,s3;
  double pR, pA, eps;
  //
  //
  // eMat - make complete
  //
  //
  eMat.fill(1); // make them all the same to start
  eMatHap.fill(1);
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Initialize eMatHap \\n";
    prev=cur;
  }
  for(iRead=0; iRead<=nReads-1; iRead++)
  {
    Rcpp::List readData = as<Rcpp::List>(sampleReads[iRead]);
    // recal that below is what is used to set each element of sampleRead
    // note - this is no longer quite accurate
    // sampleReads.push_back(Rcpp::List::create(nU,d,phiU,pRU));
    J = as<int>(readData[0]); // number of Unique SNPs on read
    readSNP = as<int>(readData[1]); // leading SNP from read
    arma::ivec bqU = as<arma::ivec>(readData[2]); // bq for SNPs
    arma::ivec pRU = as<arma::ivec>(readData[3]); // position of each SNP from 0 to T-1
    // once each SNP is done, have P(read | k), can multiply to get P(read|(k1,k2))
    if(J>=Jmax)
      J=Jmax;
    // for each SNP in the read
    for(j=0; j<=J; j++) 
    {
      // less than 0 - reference base more likely
      if(bqU(j)<0)
      {
        eps = pow(10,(double(bqU(j))/10));
        pR=1-eps;
        pA=eps/3;
      }
      if(bqU(j)>0)
      {
        eps = pow(10,(-double(bqU(j))/10));
        pR=eps/3;
        pA=1-eps;
      }
      for(k=0; k<=K-1; k++)
        eMatHap(iRead,k) = eMatHap(iRead,k) * ( eHaps(pRU(j),k) * pA + (1-eHaps(pRU(j),k)) * pR);
    }
    //
    // cap P(read|k) to be within maxDifferenceBetweenReads orders of magnitude
    //
    x=0;
    for(k=0; k<=K-1; k++)
    if(eMatHap(iRead,k)>x)
      x=eMatHap(iRead,k);
    // x is the maximum now
    for(k=0; k<=K-1; k++)
      if(eMatHap(iRead,k)<x/maxDifferenceBetweenReads)
        eMatHap(iRead,k)=x/maxDifferenceBetweenReads;
  }
  //
  // once we have all the eMatHaps, ie probabilities from reads, make eMat from this
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Initialize eMat \\n";
    prev=cur;
  }
  for(iRead=0; iRead<=nReads-1; iRead++)
  {
    Rcpp::List readData = as<Rcpp::List>(sampleReads[iRead]);
    readSNP = as<int>(readData[1]); // leading SNP from read
    for(k1=0; k1<=K-1; k1++)
    {
      for(k2=0; k2<=K-1; k2++)
      {
        // multiply by former value if >=2 reads at a locus
        eMat(readSNP,k1+K*k2) = eMat(readSNP,k1+K*k2) * (0.5 * eMatHap(iRead,k1) + 0.5 * eMatHap(iRead,k2));
      }
    }  // end of SNP in read
  } // end of loop on t
  //
  // cap eMat, ie P(reads | k1,k2) to be within maxDifferenceBetweenReads^2
  //
  d=maxDifferenceBetweenReads*maxDifferenceBetweenReads;
  for(iRead=0; iRead<=nReads-1; iRead++)
  {
    Rcpp::List readData = as<Rcpp::List>(sampleReads[iRead]);
    readSNP = as<int>(readData[1]); // leading SNP from read
    // first, get maximum
    x=0;
    for(k=0; k<=KK-1; k++)
    if(eMat(readSNP,k)>x)
      x=eMat(readSNP,k);
    // x is the maximum now
    for(k=0; k<=KK-1; k++)
      if(eMat(readSNP,k)<(x/d))
        eMat(readSNP,k)=x/d;
  } // end of loop on t
  //
  //
  // forward recursion
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Forward recursion \\n";
    prev=cur;
  }
  for(k1=0; k1<=K-1; k1++)
    for(k2=0; k2<=K-1; k2++)
      alphaHat(0,k1+K*k2) = pi(k1) * pi(k2) * eMat(0,k1+K*k2);
  c(0) = 1 / sum(alphaHat.row(0));
  alphaHat.row(0) = alphaHat.row(0) * c(0);
  //
  // forward loop
  //
  for(t=1; t<=T-1; t++)
  {
    // calculate necessary things
    alphaTemp1.fill(0);
    alphaTemp2.fill(0);
    for(k1=0; k1<=K-1; k1++) {
      for(k2=0; k2<=K-1; k2++) {
        alphaTemp1(k2) = alphaTemp1(k2) + alphaHat(t-1,k1+K*k2); // hold k1 steady
        alphaTemp2(k1) = alphaTemp2(k1) + alphaHat(t-1,k1+K*k2); // hold k2 steady
    } } // end of making alphaTemps
    // now make constant over whole thing
    alphaConst=0;
    for(k=0; k<=KK-1; k++)
      alphaConst=alphaConst + alphaHat(t-1,k);
    // new attempt
    for(k1=0; k1<=K-1; k1++)
      for(k2=0; k2<=K-1; k2++)
        alphaHat(t,k1+K*k2)=  eMat(t,k1+K*k2) * (alphaHat(t-1,k1+K*k2) * transMatRate(t-1,0) + (alphaMat(t-1,k1) * alphaTemp1(k2) + alphaMat(t-1,k2)*alphaTemp2(k1)) * transMatRate(t-1,1) + alphaMat(t-1,k1) * alphaMat(t-1,k2) * alphaConst * transMatRate(t-1,2));
    // "original"
    // do scaling now
    c(t) = 1 / sum(alphaHat.row(t));
    alphaHat.row(t) = alphaHat.row(t) * c(t);
  }
  //
  //
  //
  // backward recursion
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Backward recursion \\n";
    prev=cur;
  }
  betaHat.row(T-1).fill(c(T-1));
  for(t = T-2; t>=0; --t)
  {
    betaTemp1.fill(0);
    betaTemp2.fill(0);
    for(k1=0; k1<=K-1; k1++) {
      for(k2=0; k2<=K-1; k2++) {
        betaTemp1(k1) = betaTemp1(k1) + betaHat(t+1,k1+K*k2) * eMat(t+1,k1+K*k2) * alphaMat(t,k2);
        betaTemp2(k2) = betaTemp2(k2) + betaHat(t+1,k1+K*k2) * eMat(t+1,k1+K*k2) * alphaMat(t,k1);
    } } // end of making betaTemps
    // now make constant over whole thing
    betaConst=0;
    for(k1=0; k1<=K-1; k1++)
      for(k2=0; k2<=K-1; k2++)
        betaConst=betaConst + betaHat(t+1,k1+K*k2) * eMat(t+1,k1+K*k2)  * alphaMat(t,k1) * alphaMat(t,k2);
    // new attempt
    for(k1=0; k1<=K-1; k1++)
      for(k2=0; k2<=K-1; k2++)
        betaHat(t,k1+K*k2)=  eMat(t+1,k1+K*k2) * betaHat(t+1,k1+K*k2) * transMatRate(t,0) + transMatRate(t,1) * (betaTemp1(k1) + betaTemp2(k2)) + betaConst * transMatRate(t,2);
    // apply scaling
    betaHat.row(t) = betaHat.row(t) * c(t);
  }
  //
  // DONE looping!
  //
  //
  // make gamma
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Make gamma \\n";
    prev=cur;
  }
  gamma = alphaHat % betaHat;
  // normalize as well
  for(t= 0; t<=T-1; t++)
    gamma.row(t) = gamma.row(t) / c(t);
  //
  //
  // get dosages
  //  - only needed if final run
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Get dosages \\n";
    prev=cur; }
  if((whatToReturn == 2) | (whatToReturn==0)) // final run or debugging only
  {
    for(t=0; t<=T-1; t++)
    {
      for(k1=0; k1<=K-1;k1++)
      {
        for(k2=0; k2<=K-1;k2++)
        {
          k=k1+K*k2;
          hapProbs(t,k1)= hapProbs(t,k1) + gamma(t,k)/2;
          hapProbs(t,k2)= hapProbs(t,k2) + gamma(t,k)/2;
          genProbs(t,0)=genProbs(t,0) + gamma(t,k) * (1-eHaps(t,k1))*(1-eHaps(t,k2));
          genProbs(t,1)=genProbs(t,1) + gamma(t,k) * (eHaps(t,k1)*(1-eHaps(t,k2)) + (1-eHaps(t,k1))*eHaps(t,k2));
          genProbs(t,2)=genProbs(t,2) + gamma(t,k) * eHaps(t,k1)*eHaps(t,k2);
        } // k2
      } //k1
      for(j=1;j<=2;j++)
        dosage(t)=dosage(t)+j*genProbs(t,j)/2;
    } // end of loop on t
  } // end of if statement
  //
  //
  // do gamma update here - save large matrix, just put in necessary values
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Gamma Update \\n";
    prev=cur; }
  //
  // original version
  //
  if(model==1)
  {
    for(iRead=0; iRead<=nReads-1; iRead++)
    {
      // recal that below is what is used to set each element of sampleRead
      // sampleReads.push_back(Rcpp::List::create(nU,d,phiU,pRU));
      Rcpp::List readData = as<Rcpp::List>(sampleReads[iRead]);
      int J = as<int>(readData[0]); // number of SNPs on read
      arma::vec phiU = as<arma::vec>(readData[2]); // phi for each SNP
      arma::ivec pRU = as<arma::ivec>(readData[3]); // position of each SNP from 0 to T-1
      for(j=0; j<=J; j++) // for each SNP in the read
      {
        t=pRU(j); // position of this SNP in full T sized matrix
        // for each read, need phi, position
        for(k1=0; k1<=K-1;k1++)
        {
          a=eMatHap(iRead,k1);
          for(k2=0; k2<=K-1;k2++)
          {
            b=eMatHap(iRead,k2);
            d=a+b;
            kl=k1+K*k2;
            gammaUpdate(t,k1,0) = gammaUpdate(t,k1,0) + phiU(j) * a/d * gamma(t,kl) ;
            gammaUpdate(t,k2,0) = gammaUpdate(t,k2,0) + phiU(j) * b/d * gamma(t,kl);
            gammaUpdate(t,k1,1) = gammaUpdate(t,k1,1) + a/d * gamma(t,kl);
            gammaUpdate(t,k2,1) = gammaUpdate(t,k2,1) + b/d * gamma(t,kl);
          }
        }
      } // end loop on which SNP in the read to update
    } // end loop on reads in gamma update
  } // end of diploid model 1
  //
  //
  //
  if(model==2)
  {
    for(iRead=0; iRead<=nReads-1; iRead++)
    {
      // recal that below is what is used to set each element of sampleRead
      // sampleReads.push_back(Rcpp::List::create(nU,d,phiU,pRU));
      Rcpp::List readData = as<Rcpp::List>(sampleReads[iRead]);
      int J = as<int>(readData[0]); // number of SNPs on read
      int cr = as<int>(readData[1]); // central SNP
      arma::ivec bqU = as<arma::ivec>(readData[2]); // bq for each SNP
      arma::ivec pRU = as<arma::ivec>(readData[3]); // position of each SNP from 0 to T-1
      for(j=0; j<=J; j++) // for each SNP in the read
      {
        t=pRU(j); // position of this SNP in full T sized matrix
        //
        // first haplotype (ie (k,k1))
        //
        // less than 0 - reference base more likely
        if(bqU(j)<0)
        {
          eps = pow(10,(double(bqU(j))/10));
          pR=1-eps;
          pA=eps/3;
        }
        if(bqU(j)>0)
        {
          eps = pow(10,(-double(bqU(j))/10));
          pR=eps/3;
          pA=1-eps;
        }
        //
        //
        // RECAL  eMatHap(iRead,k) = eMatHap(iRead,k) * ( eHaps(pRU(j),k) * pA + (1-eHaps(pRU(j),k)) * pR);
        // RECAL  eMat(readSNP,k1+K*k2) = eMat(readSNP,k1+K*k2) * (0.5 * eMatHap(iRead,k1) + 0.5 * eMatHap(iRead,k2));
        //
        //
        for(k=0; k<=K-1;k++)
        {
          d1 = pA * eHaps(t,k);
          d2 = pR * (1-eHaps(t,k));
          d3 =  d1 / (d1+d2); // this is all I need
          a= eMatHap(iRead,k);
          for(k1=0; k1<=K-1;k1++)
          {
            b=eMatHap(iRead,k1);
            e=a/(a+b);
            // AM HERE
            // THINK CAREFULLY
            // emitting from the first read
            kl=k+K*k1;
            // mice 6.2 - below is cr not t
            //nov 5 2015
            gammaUpdate(t,k,0) = gammaUpdate(t,k,0) + gamma(cr,kl) * (e) * d3;
            gammaUpdate(t,k,1) = gammaUpdate(t,k,1) + gamma(cr,kl) * (e);
            // emitting from the second read
            kl=k1+K*k;
            gammaUpdate(t,k,0) = gammaUpdate(t,k,0) + gamma(cr,kl) * (e) * d3;
            gammaUpdate(t,k,1) = gammaUpdate(t,k,1) + gamma(cr,kl) * (e);
            // run6.1 has the above as e 
          } // loop on other haplotype
        } // end of loop onk
      } // end of loop on SNP within read
    } // end loop on reads in gamma update
  } // end of diploid model 2
  //
  //
  // make jUpdate
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Make xi-like calculations \\n";
    prev=cur; }
  for(t=0; t<=T-2; t++)
  {
    // start off with something that doesnt change
    alphaConst=0;
    for(k1=0; k1<=K-1; k1++)
      for(k2=0; k2<=K-1; k2++)
        alphaConst=alphaConst + alphaHat(t,k1+K*k2); // should be 1?
    alphaTemp1.fill(0);
    for(k1=0; k1<=K-1; k1++)
      for(k3=0; k3<=K-1; k3++)
        alphaTemp1(k3) = alphaTemp1(k3) + alphaHat(t,k1+K*k3); // hold k1 steady
    //
    // now do proper calculation
    //
    for(k=0; k<=K-1; k++)
    {
      for(k3=0; k3<=K-1; k3++)
        jUpdate(t,k) = jUpdate(t,k) + (transMatRate(t,1) * alphaTemp1(k3) + transMatRate(t,2) * alphaMat(t,k3)) * betaHat(t+1,k+K*k3) * eMat(t+1,k+K*k3);
      // now do other constants
      jUpdate(t,k) = jUpdate(t,k) * 2 * alphaMat(t,k);
      // 2nd jUpdate
    }   // end of loop on k
  } // end of loop on t
  //
  // 
  // if desired, calculate verterbi path
  //
  //
  //
  //
  //
  //
  //
  // done - return necessary information
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Done \\n";
    prev=cur; }
  if(whatToReturn==0) // full, debugging return
    return(wrap(Rcpp::List::create(
      Rcpp::Named("hapProbs") = hapProbs,
      Rcpp::Named("dosage") = dosage,
      Rcpp::Named("genProbs") = genProbs,
      Rcpp::Named("gammaUpdate") = gammaUpdate,
      Rcpp::Named("gamma") = gamma,
      Rcpp::Named("betaHat") = betaHat,
      Rcpp::Named("alphaHat") = alphaHat,
      Rcpp::Named("jUpdate") = jUpdate,
      Rcpp::Named("eMat") = eMat,
      Rcpp::Named("c") = c,
      Rcpp::Named("eMatHap") = eMatHap)));
  if(whatToReturn==1) // update
    return(wrap(Rcpp::List::create(
      Rcpp::Named("gammaUpdate") = gammaUpdate,
      Rcpp::Named("gamma") = gamma,
      Rcpp::Named("jUpdate") = jUpdate)));
  if(whatToReturn==2) // final run - no updating needed
    return(wrap(Rcpp::List::create(
      Rcpp::Named("hapProbs") = hapProbs,
      Rcpp::Named("gamma") = gamma,
      Rcpp::Named("dosage") = dosage,
      Rcpp::Named("genProbs") = genProbs,
      Rcpp::Named("jUpdate") = jUpdate,
      Rcpp::Named("gammaUpdate") = gammaUpdate)));
}














//' @export
// [[Rcpp::export]]
Rcpp::List forwardBackwardHaploid(Rcpp::List sampleReads, const int nReads, arma::vec pi, arma::vec sigma, arma::mat transMatRate, arma::mat alphaMat, arma::mat eHaps,   const double maxDifferenceBetweenReads, const int whatToReturn, const int Jmax, const int suppressOutput, const int model, arma::vec pRgivenH1, arma::vec pRgivenH2, arma::vec delta, arma::mat pState) {
    //  , const int skip
  double  prev=clock();
//
// immediatelly start clock to time things
//
 // 0 = verbose
  double cur;
  if( suppressOutput == 0 ) {
    cur=clock();
    std::cout << "Load variables \\n";
    prev=cur;
  }
  //
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Declare new variables \\n";
    prev=cur;
  }
//
//
// constants
//
//
  const int T = eHaps.n_rows;
  const int K = eHaps.n_cols; // traditional K for haplotypes
  const double Kd = K;
//
// new variables
//
  // variables working on nReads
  arma::mat alphaHat = arma::zeros(T,K);
  arma::mat betaHat = arma::zeros(T,K);
  arma::vec c = arma::zeros(T);
  arma::mat gamma = arma::zeros(T,K);
  // define eMatHap to work on the number of reads
  arma::mat eMatHapOri = arma::zeros(nReads,K);
  arma::mat eMatHap = arma::zeros(nReads,K);
  // eMatHapSNP works on the SNPs themselves
  arma::mat eMatHapSNP = arma::zeros(T,K);
  // variables working on full space
  arma::mat jUpdate = arma::zeros(T-1,K);
  arma::cube gammaUpdate = arma::zeros(T,K,2);
  // add an udpate for the gamma subcomponents
  arma::mat gammaUpdateS1 = arma::zeros(nReads,K);
  arma::vec gammaUpdateS2 = arma::zeros(nReads);
  // variables for transition matrix and initialization
  // int variables and such
  int pLeft, pRight, tLeft, tRight;
  int i, j, k, kk, kl, t, k1, k2, k3, k4, iRead;
  int i1, i2, j1, j2;
  int J, readSNP;
  double x, a, b, d, d1, d2, d3, a1, a2, y, phi;
  double s1,s2,s3, alphaConst;
  double pR, pA, eps, pRead;
  //
  //
  //
  // eMatHap
  //
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Initialize eMatHap \\n";
    prev=cur;
  }
  eMatHapOri.fill(1);
  for(iRead=0; iRead<=nReads-1; iRead++)
  {
    Rcpp::List readData = as<Rcpp::List>(sampleReads[iRead]);
    // recal that below is what is used to set each element of sampleRead
    // note - this is no longer quite accurate
    // sampleReads.push_back(Rcpp::List::create(nU,d,phiU,pRU));
    J = as<int>(readData[0]); // number of Unique SNPs on read
    readSNP = as<int>(readData[1]); // leading SNP from read
    arma::ivec bqU = as<arma::ivec>(readData[2]); // bq for each SNP
    arma::ivec pRU = as<arma::ivec>(readData[3]); // position of each SNP from 0 to T-1
    // once each SNP is done, have P(read | k), can multiply to get P(read|(k1,k2))
    if(J>=Jmax)
      J=Jmax;
    for(j=0; j<=J; j++) // for each SNP in the read
    {
      if(bqU(j)<0)
      {
        eps = pow(10,(double(bqU(j))/10));
        pR=1-eps;
        pA=eps/3;
      }
      if(bqU(j)>0)
      {
        eps = pow(10,(-double(bqU(j))/10));
        pR=eps/3;
        pA=1-eps;
      }
      for(k=0; k<=K-1; k++)
        eMatHapOri(iRead,k) = eMatHapOri(iRead,k) * ( eHaps(pRU(j),k) * pA + (1-eHaps(pRU(j),k)) * pR);
    } // end of j
    // previous phi based method
    //  eMatHapOri(iRead,k) = eMatHapOri(iRead,k) * ( eHaps(pRU(j),k) * phiU(j) + (1-eHaps(pRU(j),k)) * (1-phiU(j)));
    //
    // now - downweight based on probability of observing
    //
    // MODEL CHOICE
    //
    // use pState to get generic pRead probability
    if(model==8)
    {
      pRead=0;
      for(k=0; k<=K-1; k++)
        pRead=pRead+eMatHapOri(iRead,k) * pState(readSNP,k);
    }
    //
    //
    //if(model == 7 | model==8 | model==9 | model==10)
    x=pRgivenH1(iRead) / (pRgivenH1(iRead) + pRgivenH2(iRead));
    //
    // do the next part for each read
    //
    if(model==7 | model==9)
      for(k=0; k<=K-1; k++)
        eMatHap(iRead,k) = x * eMatHapOri(iRead,k) + (1-x) * pRgivenH2(iRead);
    if(model==8 | model==10)
      for(k=0; k<=K-1; k++)
        eMatHap(iRead,k) = x * eMatHapOri(iRead,k) + (1-x) * pRead;
    //for(k=0; k<=K-1; k++)
    //  eMatHap(iRead,k) = x * eMatHapOri(iRead,k) + (1-x) * pRgivenH2(iRead);
    // 
    //
    // cap P(read|k) to be within maxDifferenceBetweenReads orders of magnitude
    //
    x=0;
    for(k=0; k<=K-1; k++)
      if(eMatHap(iRead,k)>x)
        x=eMatHap(iRead,k);
    x=x/maxDifferenceBetweenReads;
    // x is the maximum now
    for(k=0; k<=K-1; k++)
      if(eMatHap(iRead,k)<x)
        eMatHap(iRead,k)=x;
  }
  //
  //
  //
  // once we have eMatHap, ie probabilities from reads, make eMatHapSNPsfrom this
  //
  //
  //
  eMatHapSNP.fill(1);
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Initialize eMat \\n";
    prev=cur;
  }
  for(iRead=0; iRead<=nReads-1; iRead++)
  {
    Rcpp::List readData = as<Rcpp::List>(sampleReads[iRead]);
    readSNP = as<int>(readData[1]); // leading SNP from read
    for(k1=0; k1<=K-1; k1++)
    {
      // multiply by former value if >=2 reads at a locus
      eMatHapSNP(readSNP,k1) = eMatHapSNP(readSNP,k1) * eMatHap(iRead,k1);
    }  // end of SNP in read
  } // end of loop on t
  //
  //
  //
  // afterwards - cap per-SNP by difference squared 
  //
  //
  //
  d=maxDifferenceBetweenReads*maxDifferenceBetweenReads;
  // now - afterward - cap 
  for(iRead=0; iRead<=nReads-1; iRead++)
  {
    Rcpp::List readData = as<Rcpp::List>(sampleReads[iRead]);
    readSNP = as<int>(readData[1]); // leading SNP from read
    // first, get maximum
    x=0;
    for(k=0; k<=K-1; k++)
    if(eMatHapSNP(readSNP,k)>x)
      x=eMatHapSNP(readSNP,k);
    // x is the maximum now
    x=x/d;
    for(k=0; k<=K-1; k++)
      if(eMatHapSNP(readSNP,k)<x)
        eMatHapSNP(readSNP,k)=x;
  } // end of loop on t
  //
  //
  //
  //
  // forward recursion
  //
  //
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Forward recursion \\n";
    prev=cur;
  }
  for(k1=0; k1<=K-1; k1++)
    alphaHat(0,k1) = pi(k1) * eMatHapSNP(0,k1);
  c(0) = 1 / sum(alphaHat.row(0));
  alphaHat.row(0) = alphaHat.row(0) * c(0);
  //
  // forward loop
  //
  for(t=1; t<=T-1; t++)
  {
    // OLD VERSION
    //for(k1=0; k1<=K-1; k1++)
    //  alphaHat(t,k1)=  eMatHapSNP(t,k1) * ( transMatRate(t-1,0) * alphaHat(t-1,k1) + transMatRate(t-1,1) * alphaMat(t-1,k1));
    // END OF OLD VERSION
    // fixed July 22, 2015
    // make the constant
    alphaConst=0;
    for(k=0; k<=K-1; k++)
      alphaConst=alphaConst + alphaHat(t-1,k);
    alphaConst=alphaConst * transMatRate(t-1,1);
    //
    // each entry is emission * (no change * that value + constant)
    for(k=0; k<=K-1; k++)
      alphaHat(t,k) =  eMatHapSNP(t,k) * ( transMatRate(t-1,0) * alphaHat(t-1,k) + alphaConst * alphaMat(t-1,k));
    // do scaling now
    c(t) = 1 / sum(alphaHat.row(t));
    alphaHat.row(t) = alphaHat.row(t) * c(t);
  }
  //
  //
  //
  // backward recursion
  //
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Backward recursion \\n";
    prev=cur;
  }
  betaHat.row(T-1).fill(c(T-1));
  for(t = T-2; t>=0; --t)
  {
    // x is Bt
    x=0;
    //  
    for(k1=0; k1<=K-1; k1++)
      x=x + alphaMat(t,k1) * eMatHapSNP(t+1,k1) * betaHat(t+1,k1);
    x=x*transMatRate(t,1);
    //
    for(k1=0; k1<=K-1; k1++)
      betaHat(t,k1) = x + transMatRate(t,0) * eMatHapSNP(t+1,k1) * betaHat(t+1,k1);
    // apply scaling
    betaHat.row(t) = betaHat.row(t) * c(t);
  }
  //
  //
  //
  // make gamma
  //
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Make gamma \\n";
    prev=cur;
  }
  gamma = alphaHat % betaHat;
  // normalize as well
  for(t= 0; t<=T-1; t++)
    gamma.row(t) = gamma.row(t) / c(t);
  //
  //
  //
  // hap probs are gamma!
  //
  //
  //
  // do gamma update here - save large matrix, just put in necessary values
  //
  //
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Gamma Update \\n";
    prev=cur; }
  //
  //
  // note - have just copy, pasted below 2 times for different options
  // really should be a function! my laziness
  //
  //
  // still doing gamma update - next, method 7
  //
  if(model==7 | model==8)
  {
    for(iRead=0; iRead<=nReads-1; iRead++)
    {
      // recal that below is what is used to set each element of sampleRead
      // sampleReads.push_back(Rcpp::List::create(nU,d,phiU,pRU));
      Rcpp::List readData = as<Rcpp::List>(sampleReads[iRead]);
      int J = as<int>(readData[0]); // number of SNPs on read
      int cr = as<int>(readData[1]); // central SNP in read
      arma::ivec bqU = as<arma::ivec>(readData[2]); // bq for each SNP
      arma::ivec pRU = as<arma::ivec>(readData[3]); // position of each SNP from 0 to T-1
      for(j=0; j<=J; j++) // for each SNP in the read
      {
        t=pRU(j); // position of this SNP in full T sized matrix
        //
        // first haplotype (ie (k,k1))
        //
        for(k=0; k<=K-1;k++)
        {
          // less than 0 - reference base more likely
          if(bqU(j)<0)
          {
            eps = pow(10,(double(bqU(j))/10));
            pR=1-eps;
            pA=eps/3;
          }
          if(bqU(j)>0)
          {
            eps = pow(10,(-double(bqU(j))/10));
            pR=eps/3;
            pA=1-eps;
          }
          //
          //
          //    
          x=pRgivenH1(iRead) / (pRgivenH1(iRead) + pRgivenH2(iRead));
          d1 = x * pA * eHaps(t,k);
          d2 = x * pR * (1-eHaps(t,k));
          d= gamma(t,k) / eMatHap(iRead,k) ;
          // d1 = x * phiU(j) * eHaps(t,k);
          // d2 = x * (1-phiU(j)) * (1-eHaps(t,k));
          // d3 = d1 + d2 + (1-x) * pRgivenH2(iRead); // denom
          gammaUpdate(t,k,0) = gammaUpdate(t,k,0) + d * d1;
          gammaUpdate(t,k,1) = gammaUpdate(t,k,1) + d * (d1 + d2);
        } // end of k
      } // end of SNP in read 
    } // end of read
  } // end of method 7
  //
  //
  // & skip==0
  if((model==9 | model==10))
  {
    for(iRead=0; iRead<=nReads-1; iRead++)
    {
      // recal that below is what is used to set each element of sampleRead
      // sampleReads.push_back(Rcpp::List::create(nU,d,phiU,pRU));
      Rcpp::List readData = as<Rcpp::List>(sampleReads[iRead]);
      int J = as<int>(readData[0]); // number of SNPs on read
      int cr = as<int>(readData[1]); // central SNP in read
      arma::ivec bqU = as<arma::ivec>(readData[2]); // bq for each SNP
      arma::ivec pRU = as<arma::ivec>(readData[3]); // position of each SNP from 0 to T-1
      for(j=0; j<=J; j++) // for each SNP in the read
      {
        t=pRU(j); // position of this SNP in full T sized matrix
        //
        // first haplotype (ie (k,k1))
        //
        for(k=0; k<=K-1;k++)
        {
          // less than 0 - reference base more likely
          if(bqU(j)<0)
          {
            eps = pow(10,(double(bqU(j))/10));
            pR=1-eps;
            pA=eps/3;
          }
          if(bqU(j)>0)
          {
            eps = pow(10,(-double(bqU(j))/10));
            pR=eps/3;
            pA=1-eps;
          }
          //  RECALL eMatHapOri(iRead,k) = eMatHapOri(iRead,k) * ( eHaps(pRU(j),k) * pA + (1-eHaps(pRU(j),k)) * pR);
          //  RECALL eMatHap(iRead,k) = x * eMatHapOri(iRead,k) + (1-x) * pRgivenH2(iRead);
          a1=pA * eHaps(t,k);
          a2=pR * (1-eHaps(t,k)); 
          y=a1+a2;
          b=eMatHapOri(iRead,k)/y * pRgivenH1(iRead) / (pRgivenH1(iRead) + pRgivenH2(iRead));
          d1 = a1 * b;
          d2 = a2 * b;
          d= gamma(cr,k) / eMatHap(iRead,k);
          gammaUpdate(t,k,0) = gammaUpdate(t,k,0) + d * d1;
          gammaUpdate(t,k,1) = gammaUpdate(t,k,1) + d * (d1 + d2);
        } // end of k
      } // end of SNP in read 
    } // end of read
  } // end of method 9
  //
  //
  //
  //
  // make jUpdate
  //
  //
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Make xi-like calculations \\n";
    prev=cur; }
  for(t=0; t<=T-2; t++)
  {
    for(k1=0; k1<=K-1; k1++)
      jUpdate(t,k1) = transMatRate(t,1) * alphaMat(t,k1) * betaHat(t+1,k1) * eMatHapSNP(t+1,k1);
  } // end of loop on t
  //
  //
  //
  if( suppressOutput == 0 ) {
    cur=clock();
    printf ("%.3f cpu sec\\n", ((double)cur - (double)prev)* 1.0e-6);
    std::cout << "Done \\n";
    prev=cur; }
  if(whatToReturn==0) // full, debugging return
    return(wrap(Rcpp::List::create(
      Rcpp::Named("alphaHat") = alphaHat,
      Rcpp::Named("betaHat") = betaHat,
      Rcpp::Named("c") = c,
      Rcpp::Named("gammaUpdate") = gammaUpdate,
      Rcpp::Named("gammaUpdateS1") = gammaUpdateS1,
      Rcpp::Named("gammaUpdateS2") = gammaUpdateS2,
      Rcpp::Named("eMatHapOri") = eMatHapOri,
      Rcpp::Named("gamma") = gamma,
      Rcpp::Named("jUpdate") = jUpdate,
      Rcpp::Named("eMatHap") = eMatHap)));
  if(whatToReturn==1) // update
    return(wrap(Rcpp::List::create(
      Rcpp::Named("gammaUpdate") = gammaUpdate,
      Rcpp::Named("gammaUpdateS1") = gammaUpdateS1,
      Rcpp::Named("gammaUpdateS2") = gammaUpdateS2,
      Rcpp::Named("gamma") = gamma,
      Rcpp::Named("eMatHap") = eMatHap,
      Rcpp::Named("eMatHapOri") = eMatHapOri,
      Rcpp::Named("jUpdate") = jUpdate)));
  if(whatToReturn==2) // same thing here - for simplicity 
    return(wrap(Rcpp::List::create(
      Rcpp::Named("gammaUpdate") = gammaUpdate,
      Rcpp::Named("gammaUpdateS1") = gammaUpdateS1,
      Rcpp::Named("gammaUpdateS2") = gammaUpdateS2,
      Rcpp::Named("gamma") = gamma,
      Rcpp::Named("eMatHap") = eMatHap,
      Rcpp::Named("eMatHapOri") = eMatHapOri,
      Rcpp::Named("jUpdate") = jUpdate)));
}



//' @export
// [[Rcpp::export]]
List cpp_read_reassign(arma::ivec ord, arma::ivec qnameInteger_ord, List sampleReadsRaw, int verbose) {
  // ord is 0-based original ordering
  // qnameInteger_ord is (ordered) integer representing reads
  
  // initialize
  List sampleReads;
  int curRead = qnameInteger_ord[0];
  int iReadStart = 0;
  int nRawReads = sampleReadsRaw.size();
  arma::ivec base_bq(1000);
  arma::ivec base_pos(1000); // there shouldnt be this many SNPs
  if(verbose == 1) {
    std::cout << "curRead=" << curRead << "\n";
  }
  for (int iRead = 0; iRead < nRawReads; iRead++ ) {
    
    if(verbose == 1) {
      std::cout << "iRead=" << iRead << "\n";
      std::cout << "qnameInteger_ord[iRead + 1]=" << qnameInteger_ord[iRead + 1] << "\n";
      std::cout << "curRead==" << curRead << "\n";    
    }
    
    if (qnameInteger_ord[iRead + 1] != curRead) {
      
      int nSNPsInRead = -1;
      for(int j = iReadStart; j <= iRead; j++) {

	int r = ord[j];
	
	if(verbose == 1) {
	  std::cout << "j=" << j << "\n";
	  std::cout << "r=" << r << "\n";
	}
	
	// so say first read is 0-based 0:2
        // want to take reads from ord[0:2]
	Rcpp::List readData = as<Rcpp::List>(sampleReadsRaw[r]);
	arma::ivec bqU = as<arma::ivec>(readData[2]);
	arma::ivec pRU = as<arma::ivec>(readData[3]);
	for(int k = 0; k < int(bqU.size()); k++) {
	  // std::cout << "k=" << k << "\n";
	  nSNPsInRead++;
	  base_bq[nSNPsInRead] = bqU[k];
	  base_pos[nSNPsInRead] = pRU[k];	  
	}
      }

      arma::ivec bqL = base_bq.subvec(0, nSNPsInRead);
      arma::ivec posL = base_pos.subvec(0, nSNPsInRead);
      sampleReads.push_back(Rcpp::List::create(nSNPsInRead, 0, bqL, posL));
      iReadStart = iRead + 1;
      curRead = qnameInteger_ord[iRead + 1]; // + 1
      if(verbose == 1) {
	std::cout << "reset curRead=" << curRead << "\n";
      }
      
    }
    
  }
  
  return sampleReads;
}



