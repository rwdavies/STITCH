library(testthat)
library(STITCH)

test_check("STITCH")
