setwd("/data/smew1/rdavies/stitch_development/STITCH_github_latest/STITCH/STITCH/R/")
library("STITCH")
library("testthat")
source("test-drivers.R")
source("functions.R")


n_snps <- 10
L <- c(10, 1:9)
refpack <- make_reference_package(
    n_snps = n_snps,
    n_samples_per_pop = 4,
    reference_populations = c("CEU", "GBR", "CHB"),
    refs = rep("A", n_snps),
    alts = rep("G", n_snps),
    L = L
)
    
        get_haplotypes_from_reference(
            reference_haplotype_file = refpack$reference_haplotype_file,
            reference_legend_file = refpack$reference_legend_file,
            reference_populations = refpack$reference_populations,
            pos = refpack$pos
        )
