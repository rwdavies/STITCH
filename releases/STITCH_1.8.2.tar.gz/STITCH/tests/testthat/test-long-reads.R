
skip("local" )

chr <- "chr22"
regionStart <- 48834669
regionEnd <- 55783303
chrStart <- 48834669
chrEnd <- 55783303
regionName <- chr
if (!is.na(regionStart) & !is.na(regionEnd)) {
  regionName <- paste0(chr, ".", regionStart,".", regionEnd)
}
iSizeUpperLimit <- 1000000
bqFilter <- 0
use_bx_tag <- FALSE
default_sample_no_read_behaviour <- "return_null"
## maxnSNPInRead = 1e6
## chrLength = NA

pos <- readRDS("~/Downloads/pos.rds")
fed(pos)
bamfile <- file.path("/home/zilong/Downloads/suppl.bam")
bamfile <- file.path("/home/zilong/Downloads/test-addrg-NA12878.bam")


L = as.integer(pos[, 2])
nSNPs = as.integer(nrow(pos))
ref <- as.character(pos[, "REF"])
alt <- as.character(pos[, "ALT"])

out <- get_sampleReadsRaw_from_SeqLib(
  bqFilter = bqFilter,
  iSizeUpperLimit = iSizeUpperLimit,
  ref = ref,
  alt = alt,
  nSNPs = nSNPs,
  L = L,
  region = paste0(chr, ":", chrStart, "-", chrEnd),
  file_name = bamfile,
  reference = "",
  save_sampleReadsInfo = TRUE,
  useSoftClippedBases = FALSE,
  use_bx_tag = FALSE
)

strand <- out$strand
table(strand)

sampleReadsRaw <- out$sampleReadsRaw
qname <- out$qname
qname_all <- out$qname_all

length(unique(qname_all))
length(unique(qname))

all <- unique(qname_all)

all[!all%in%qname][1]
"916df8c3-c4f4-4343-af60-149b68d6575f"
pos[,2][1]

pos[150981,2]

match(pos[,2][10], pos[,2])

pos[pos[,2] > bp,][1:10,]
tail(pos[,2][pos[,2] < bp], n=10)

bp <- 48960033

inputdir <- tempdir()
inputdir

loadBamAndConvert(
  iBam = 1,
  L = as.integer(pos[, 2]),
  pos = pos,
  nSNPs = as.integer(nrow(pos)),
  bam_files = bamfile,
  N = 1,
  sampleNames = "NA12878",
  inputdir = inputdir,
  regionName = regionName,
  tempdir = tempdir(),
  chr = chr,
  chrStart = regionStart,
  chrEnd = regionEnd,
  useSoftClippedBases = TRUE,
  save_sampleReadsInfo = TRUE,
  iSizeUpperLimit = iSizeUpperLimit,
  bqFilter = bqFilter,
  default_sample_no_read_behaviour = "return_null"
)

load(file_sampleReads(inputdir, 1, regionName))
length(sampleReads) ## 272

sample_alleleCount <- get_alleleCount(sampleReads, nrow(pos))
mean(sample_alleleCount[,2])

library(QUILT)

get_alleleCount <- function(sampleReads , nSNPs) {
    alleleCount <- array(0,c(nSNPs, 3))
    a=unlist(sapply(sampleReads,function(x) x[[3]]))
    b=unlist(sapply(sampleReads,function(x) x[[4]]))
    bqProbs=convertScaledBQtoProbs(matrix(a,ncol=1))
    ## y is numeric, z = integer counts (can have 0),
    c1 <- increment2N(
        y = as.numeric(bqProbs[,1]),
        z = as.numeric(b),
        yT = as.integer(nrow(bqProbs)),
        xT = as.integer(nSNPs - 1)
    )
    c2 <- increment2N(
        y = as.numeric(bqProbs[,2]),
        z = as.numeric(b),
        yT = as.integer(nrow(bqProbs)),
        xT = as.integer(nSNPs - 1)
    )
    alleleCount[,1]=alleleCount[,1]+c2 # fixed nov 6 2015 - was backward
    alleleCount[,2]=alleleCount[,2]+c1+c2
    return(alleleCount)
}
