test_that("decoy", {

    skip("wer")
nSNPs <- 1500
N <- 100

gp <- matrix(runif(nSNPs * 3), nrow = nSNPs, 3)        
vcf_matrix_to_out <- data.frame(matrix(
    data = NA,
    nrow = nSNPs,
    ncol = N
))

for(i_sample in 1:N) {
    gp <- matrix(runif(nSNPs * 3), nrow = nSNPs, 3)
    vcf_matrix_to_out[, i_sample] <- rcpp_make_column_of_vcf(gp, 0, matrix())
}


## initialize, put in, write
test1 <- function() {
    vcf_matrix_to_out <- matrix(
        data = NA,
        nrow = nSNPs,
        ncol = N
    )
    for(i_sample in 1:N) {
        gp <- matrix(runif(nSNPs * 3), nrow = nSNPs, 3)
        vcf_matrix_to_out[, i_sample] <- rcpp_make_column_of_vcf(gp, 0, matrix())        
    }
    write.table(
        vcf_matrix_to_out,
        file = gzfile(tempfile()),
        row.names = FALSE,
        col.names = FALSE,
        sep = "\t",
        quote = FALSE
    )
}

## initialize, put in, write
test2 <- function(is_matrix = TRUE) {
    vcf_matrix_to_out <- data.frame(matrix(
        data = NA,
        nrow = nSNPs,
        ncol = N
    ))
    for(i_sample in 1:N) {
        gp <- matrix(runif(nSNPs * 3), nrow = nSNPs, 3)
        vcf_matrix_to_out[, i_sample] <- rcpp_make_column_of_vcf(gp, 0, matrix())                
    }
    file <- tempfile()
    fwrite(
        x = vcf_matrix_to_out,
        file = file,
        sep = "\t"
    )
    system(paste0("gzip -1 ", file))
}


## initialize, put in, write
test2A <- function() {
    vcf_matrix_to_out <- data.frame(matrix(
        data = NA,
        nrow = nSNPs,
        ncol = N
    ))
    return(NULL)
}
test2B <- function() {
    for(i_sample in 1:N) {
        vcf_matrix_to_out[, i_sample] <- make_column_of_vcf(
            gp,
            read_proportions = NULL
        )
    }
    return(NULL)
}
test2B2 <- function() {
    for(i_sample in 1:N) {
        vcf_matrix_to_out[, i_sample] <- rcpp_make_column_of_vcf(gp, 0, matrix())
    }
    return(NULL)
}

test2C <- function() {
    file <- tempfile()
    data.table::fwrite(
        x = vcf_matrix_to_out,
        file = file,
        sep = "\t"
    )
    system(paste0("gzip -1 ", file))
}
test2D <- function() {
    write.table(
        vcf_matrix_to_out,
        file = gzfile(tempfile()),
        row.names = FALSE,
        col.names = FALSE,
        sep = "\t",
        quote = FALSE
    )
}



print("START speed-test")
## initialization meaningless, building is most of it
## turn into C++! 
library("microbenchmark")
print(microbenchmark::microbenchmark(
    test2A(),
    test2B(),
    test2B2(),
    test2C(),
    test2D(),
    times = 2
))
print("END speed-test")
## yikes, much slower!
## so re-write middle bit in C++
## then re-write outputter using fwrite









})
