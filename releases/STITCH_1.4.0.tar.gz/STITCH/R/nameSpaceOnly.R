#' @useDynLib STITCH
#' @importFrom Rcpp sourceCpp
NULL
