pwd
d=/data/smew1/rdavies/stitch_development/STITCH_github_latest/STITCH/STITCH/src/SeqLib/
g++ -I. -I${d}/json/ -I${d}/SeqLib/ -I${d}/htslib/  ${d}/src/libseqlib.a ${d}/htslib/libhts.a -c test.cpp -o test.o
exit


//-m64 -std=gnu++11 -I/usr/include/R -DNDEBUG -I./SeqLib// -I./SeqLib//htslib/ -I"/homes/rdavies/R/x86_64-redhat-linux-gnu-library/3.4/Rcpp/include" -I"/homes/rdavies/R/x86_64-redhat-linux-gnu-library/3.4/RcppArmadillo/include" -I/usr/local/include   -fpic  -O2 -g -pipe -Wall -Werror=format-security -Wp,-D_FORTIFY_SOURCE=2 -fexceptions -fstack-protector-strong --param=ssp-buffer-size=4 -grecord-gcc-switches -specs=/usr/lib/rpm/redhat/redhat-hardened-cc1 -m64 -mtune=generic
