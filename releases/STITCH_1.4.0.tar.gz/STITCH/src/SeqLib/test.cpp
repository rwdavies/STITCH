#include <SeqLib/BamReader.h>
using namespace SeqLib;
SeqLib::BamReader r;

// read from multiple streams coordinate-sorted order
r.Open("test_data/small.bam");
r.Open("test_data/small.cram");
r.Open("test_data/small.sam");

SeqLib::BamWriter w(SeqLib::SAM); // set uncompressed output
w.Open("-");              // write to stdout
w.SetHeader(r.Header());  // specify the header
w.WriteHeader();          // write out the header

SeqLib::BamRecord rec;
while(r.GetNextRecord(rec))
  w.WriteRecord(rec);
w.Close();               // Optional. Will close on destruction
r.Close();
